<?php 

    $host = "localhost";
    $port = 3306;
    $username = 'root';
    $password = '';
    $db_name = 'portofolio';

    $db = mysqli_connect($host, $username, $password, $db_name, $port);

    if ($db->connect_error) {
        echo'database error';
        die($db);
    }

?>
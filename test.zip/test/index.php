<?php 

include './service/database.php';
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TEST</title>
    <link rel="stylesheet" href="./public/dist/css/main.css">
</head>
<body>
    <?php include './public/layout/navbar.php'?>
</body>
</html>

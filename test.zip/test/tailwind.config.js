/** @type {import('tailwindcss').Config} */
// npx tailwindcss -i ./src/input.css -o ./public/dist/css/main.css --watch
module.exports = {
  content: [
    "./index.php"
  ],
  theme: {
    container:{
      padding:'16px',
      center:true
    },
    extend: {
      screens:'1300px'
    },
  },
  plugins: [],
}


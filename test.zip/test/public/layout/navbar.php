<nav class="w-full h-16 bg-white shadow-md flex">
    <div class="container flex self-center">
        <h1 class="self-center">PORTOFOLIO</h1>
    </div>
</nav>
